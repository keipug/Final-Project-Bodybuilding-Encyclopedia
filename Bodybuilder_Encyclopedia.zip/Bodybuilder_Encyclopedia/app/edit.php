<?php
include '../lib/config.php';
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}
$dataDirectory = __DIR__ . '/data/';
if (!is_dir($dataDirectory)) {
    die("Data directory does not exist.");
}
$textFiles = glob($dataDirectory . '*.txt');
if (isset($_GET['file'])) {
    $fileName = basename($_GET['file']);
    $filePath = $dataDirectory . $fileName;
    if (!file_exists($filePath) || pathinfo($filePath, PATHINFO_EXTENSION) !== 'txt') {
        die("Invalid or non-existent file.");
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $updatedContent = $_POST['file_content'] ?? '';
        if (file_put_contents($filePath, $updatedContent) !== false) {
            $message = "File updated successfully!";
        } else {
            $message = "Failed to update the file.";
        }
    }
    $fileContent = htmlspecialchars(file_get_contents($filePath), ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Files</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <?php include '../theme/header3.php'; ?>
    <div class="container">
        <h1>Manage Text Files</h1>
        <h2>Available Files</h2>
        <ul class="list-group mb-4">
            <?php foreach ($textFiles as $file): ?>
                <li class="list-group-item">
                    <a href="edit.php?file=<?php echo urlencode(basename($file)); ?>">
                        <?php echo htmlspecialchars(basename($file), ENT_QUOTES, 'UTF-8'); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php if (isset($fileName)): ?>
            <h2>Edit File: <?php echo htmlspecialchars($fileName, ENT_QUOTES, 'UTF-8'); ?></h2>
            <?php if (isset($message)): ?>
                <div class="alert <?php echo strpos($message, 'successfully') !== false ? 'alert-success' : 'alert-danger'; ?>">
                    <?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>
            <form action="edit.php?file=<?php echo urlencode($fileName); ?>" method="POST">
                <div class="mb-3">
                    <label for="file_content" class="form-label">File Content</label>
                    <textarea class="form-control" id="file_content" name="file_content" rows="10"><?php echo $fileContent; ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <a href="home.php" class="btn btn-secondary">Back to home</a>
            </form>
        <?php endif; ?>
    </div>
    <?php include '../theme/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../theme/js/scripts.js"></script>
</body>
</html>
