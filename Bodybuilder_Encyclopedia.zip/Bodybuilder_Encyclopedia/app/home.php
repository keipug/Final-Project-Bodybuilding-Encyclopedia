<?php
include '../lib/config.php';
session_start();
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : null;
function readTextFile($file) {
    return file_get_contents($file);
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Personal - Start Bootstrap Theme</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="../theme/css/styles.css" rel="stylesheet" />
    </head>
    <body class="d-flex flex-column h-100">
        <main class="flex-shrink-0">
            <?php include '../theme/header3.php'; ?>
            <header class="py-5">
                <div class="container px-5 pb-5">
                    <div class="row gx-5 align-items-center">
                        <div class="col-xxl-5">
                            <div class="text-center text-xxl-start">
                                <h1 class="display-3 fw-bolder mb-5"><span class="text-gradient d-inline"><?php echo readTextFile('data/Title.txt') ?></span></h1>
                                <div class="d-grid gap-3 d-sm-flex justify-content-sm-center justify-content-xxl-start mb-3">
                                    <a class="btn btn-primary btn-lg px-5 py-3 me-sm-3 fs-6 fw-bolder" href="bodybuilders/index.php"><?php echo "Index"?></a>
                                    <?php if ($user_role == null): ?>
                                    <a class="btn btn-outline-dark btn-lg px-5 py-3 fs-6 fw-bolder" href="../lib/auth/sign_in.php"><?php echo "Sign In"?></a>
                                    <?php endif; ?>
                                    <?php if ($user_role === 'admin'): ?>
                                        <a class="btn btn-outline-dark btn-lg px-5 py-3 fs-6 fw-bolder" href="edit.php"><?php echo "Edit"?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-7">
                        </div>
                    </div>
                </div>
            </header>
            <section class="bg-light py-5">
                <div class="container px-5">
                    <div class="row gx-5 justify-content-center">
                        <div class="col-xxl-8">
                            <div class="text-center my-5">
                                <h2 class="display-5 fw-bolder"><span class="text-gradient d-inline">About Us</span></h2>
                                <p class="text-muted"><?php echo readTextFile('data/About_Us.txt') ?></p>
                                <div class="d-flex justify-content-center fs-2 gap-4">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <?php include '../theme/footer.php'; ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="../theme/js/scripts.js"></script>
    </body>
</html>
