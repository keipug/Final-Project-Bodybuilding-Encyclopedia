<?php
include '../../lib/config.php';
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}
$image_error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = htmlspecialchars($_POST['full_name'], ENT_QUOTES, 'UTF-8');
    $height = filter_var($_POST['height'], FILTER_VALIDATE_FLOAT);
    $weight = filter_var($_POST['weight'], FILTER_VALIDATE_FLOAT);
    $competitions = htmlspecialchars($_POST['competitions'], ENT_QUOTES, 'UTF-8');
    $created_id = $_SESSION['user_id'] ?? null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $allowed_types = ['image/jpeg', 'image/png'];
        $file_type = mime_content_type($_FILES['image']['tmp_name']);
        if (in_array($file_type, $allowed_types)) {
            $image_name = strtolower(str_replace(' ', '_', $full_name)) . '.png';
            $image_path = "../data/" . $image_name;
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
                $image_error = 'Error uploading image.';
            }
        } else {
            $image_error = 'Invalid image type. Please upload a PNG or JPEG.';
        }
    } else {
        $image_error = 'Image upload is required.';
    }
    if (empty($image_error)) {
        $sql = "INSERT INTO bodybuilders (full_name, height, weight, competitions_won, img_location, created_by) 
                VALUES (:full_name, :height, :weight, :competitions, :img_location, :created_by)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':full_name' => $full_name,
            ':height' => $height,
            ':weight' => $weight,
            ':competitions' => $competitions,
            ':img_location' => '../data/' . $image_name,
            ':created_by' => $created_id
        ]);
        header("Location: index.php?success=true");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Create new bodybuilder" />
    <meta name="author" content="Bodybuilding CMS" />
    <title>Create Bodybuilder</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="d-flex flex-column h-100">
    <main class="flex-shrink-0">
        <?php include '../../theme/header.php'; ?>
        <div class="container mt-5">
            <h2>Create New Bodybuilder</h2>
            <?php if (!empty($image_error)): ?>
                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($image_error, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>
            
            <form action="create.php" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="full_name" class="form-label">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" required />
                </div>
                <div class="mb-3">
                    <label for="height" class="form-label">Height (in cm)</label>
                    <input type="number" class="form-control" id="height" name="height" step="0.01" required />
                </div>
                <div class="mb-3">
                    <label for="weight" class="form-label">Weight (in kg)</label>
                    <input type="number" class="form-control" id="weight" name="weight" required />
                </div>
                <div class="mb-3">
                    <label for="competitions" class="form-label">Competitions Won (Comma Separated)</label>
                    <input type="text" class="form-control" id="competitions" name="competitions" required />
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Upload Image</label>
                    <input type="file" class="form-control" id="image" name="image" accept="image/*" required />
                </div>
                <button type="submit" class="btn btn-success">Create Bodybuilder</button>
            </form>
        </div>
    </main>
    <?php include '../../theme/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
