<?php
include '../../lib/config.php';
session_start();
$bodybuilders = include '../../lib/fetch_bodybuilders.php';
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Bodybuilders</title>
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet" />
    <link href="../../theme/css/styles.css" rel="stylesheet" />
</head>
<body class="d-flex flex-column h-100">
    <main class="flex-shrink-0">
        <?php include '../../theme/header.php'; ?>
        <?php if ($user_role === 'admin'): ?>
            <div class="container mt-3">
                <a href="create.php" class="btn btn-success">Add New Bodybuilder</a>
            </div>
        <?php endif; ?>
        
        <section class="bg-light py-5">
            <?php foreach ($bodybuilders as $bodybuilder): ?>
                <div class="container px-5">
                    <div class="row gx-5 justify-content-center">
                        <div class="col-xxl-4 col-md-6 mb-5">
                            <div class="card">
                                <img src="<?php echo $bodybuilder['img_location']; ?>" alt="<?php echo $bodybuilder['full_name']; ?>" class="card-img-top" />
                                <div class="card-body text-center">
                                    <h5 class="card-title"><?php echo $bodybuilder['full_name']; ?></h5>
                                    <a href="detail.php?id=<?php echo $bodybuilder['id']; ?>" class="btn btn-info">Details</a>
                                    <?php if ($user_role !== null): ?>
                                        <div class="d-flex justify-content-center gap-3">
                                            <a href="edit.php?id=<?php echo $bodybuilder['id']; ?>" class="btn btn-warning">Edit</a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($user_role === 'admin'): ?>
                                        <div class="d-flex justify-content-center gap-3">
                                            <a href="delete.php?id=<?php echo $bodybuilder['id']; ?>" class="btn btn-danger">Delete</a>
                                        </div>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </section>
    </main>
    <?php include '../../theme/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../theme/js/scripts.js"></script>
</body>
</html>
