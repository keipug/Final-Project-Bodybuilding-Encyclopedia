<?php
session_start();
include '../../lib/config.php';
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../lib/auth/sign_in.php");
    exit();
}
if (isset($_GET['id'])) {
    $bodybuilderId = $_GET['id'];
    $sql = "DELETE FROM bodybuilders WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $bodybuilderId]);
    header("Location: index.php");
    exit();
} else {
    echo "No bodybuilder ID provided!";
    exit();
}
