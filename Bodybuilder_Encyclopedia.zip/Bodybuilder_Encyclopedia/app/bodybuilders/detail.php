<?php
session_start();
include '../../lib/config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../lib/auth/sign_in.php');
    exit();
}
$userId = $_SESSION['user_id'];
$sql = "SELECT role FROM users WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $userId]);
$loggedInUser = $stmt->fetch(PDO::FETCH_ASSOC);
if (!isset($_GET['id'])) {
    echo "No bodybuilder ID provided!";
    exit();
}
$bodybuilderId = $_GET['id'];
$sql = "SELECT * FROM bodybuilders WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $bodybuilderId]);
$bodybuilder = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$bodybuilder) {
    echo "Bodybuilder not found!";
    exit();
}
$isAdmin = $loggedInUser['role'] === 'admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bodybuilder Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../../theme/header.php'; ?>
    <div class="container mt-5">
        <h2>Bodybuilder Details</h2>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Name: <?php echo htmlspecialchars($bodybuilder['full_name']); ?></h5>
                <p class="card-text">Height: <?php echo htmlspecialchars($bodybuilder['height']); ?> cm</p>
                <p class="card-text">Weight: <?php echo htmlspecialchars($bodybuilder['weight']); ?> kg</p>
                <p class="card-text">Competitions Won: <?php echo htmlspecialchars($bodybuilder['competitions_won']); ?></p>
                <img src="<?php echo htmlspecialchars($bodybuilder['img_location']); ?>" alt="Bodybuilder Image" class="img-fluid">
            </div>
        </div>
        <?php if ($isAdmin): ?>
            <p class="card-text">Created by: <?php echo htmlspecialchars($bodybuilder['created_by']); ?></p>
            <p class="card-text">Last edited by: <?php echo htmlspecialchars($bodybuilder['last_edited_by']); ?></p>
            <form method="POST" action="delete.php?id=<?php echo $bodybuilderId; ?>" class="mt-3">
                <button  href="delete.php?id=<?php echo $bodybuilder['id']; ?>" class="btn btn-danger">Delete</button>
            </form>
        <?php endif; ?>
        <a href="edit.php?id=<?php echo $bodybuilderId; ?>" class="btn btn-warning mt-3">Edit Bodybuilder</a>
        <a href="index.php" class="btn btn-primary mt-3">Back to Bodybuilder List</a>
    </div>
    <?php include '../../theme/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../theme/js/scripts.js"></script>
</body>
</html>
