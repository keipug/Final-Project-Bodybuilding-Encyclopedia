<?php
include '../../lib/config.php';
session_start();
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $bodybuilderId = intval($_GET['id']);
    $sql = "SELECT * FROM bodybuilders WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $bodybuilderId]);
    $bodybuilder = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$bodybuilder) {
        echo "Bodybuilder not found!";
        exit;
    }
} else {
    echo "No bodybuilder ID provided!";
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = htmlspecialchars($_POST['full_name'], ENT_QUOTES, 'UTF-8');
    $height = filter_var($_POST['height'], FILTER_VALIDATE_FLOAT);
    $weight = filter_var($_POST['weight'], FILTER_VALIDATE_FLOAT);
    $competitions = htmlspecialchars($_POST['competitions'], ENT_QUOTES, 'UTF-8');
    $last_edited_by = $_SESSION['user_id'] ?? null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png'];
        $file_type = mime_content_type($_FILES['image']['tmp_name']);
        if (in_array($file_type, $allowed_types)) {
            $image_name = strtolower(str_replace(' ', '_', $full_name)) . '.png';
            $target_dir = '../../data/';
            $target_file = $target_dir . $image_name;
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                echo "Error uploading image!";
                exit;
            }
            $img_location = $image_name;
        } else {
            echo "Invalid image type. Please upload a PNG or JPEG.";
            exit;
        }
    } else {
        $img_location = $bodybuilder['img_location'];
    }
    $sql = "UPDATE bodybuilders SET 
                full_name = :full_name, 
                height = :height, 
                weight = :weight, 
                competitions_won = :competitions, 
                img_location = :img_location, 
                last_edited_by = :last_edited_by 
            WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':full_name' => $full_name,
        ':height' => $height,
        ':weight' => $weight,
        ':competitions' => $competitions,
        ':img_location' => $img_location,
        ':id' => $bodybuilderId,
        ':last_edited_by' => $last_edited_by
    ]);

    header("Location: detail.php?id=" . $bodybuilderId);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Edit Bodybuilder" />
    <meta name="author" content="Bodybuilding CMS" />
    <title>Edit Bodybuilder</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
    <?php include '../../theme/header.php'; ?>
    <div class="container py-5">
        <h2>Edit Bodybuilder</h2>
        <form action="edit.php?id=<?php echo htmlspecialchars($bodybuilder['id'], ENT_QUOTES, 'UTF-8'); ?>" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="full_name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($bodybuilder['full_name'], ENT_QUOTES, 'UTF-8'); ?>" required>
            </div>
            <div class="mb-3">
                <label for="height" class="form-label">Height</label>
                <input type="number" step="0.01" class="form-control" id="height" name="height" value="<?php echo htmlspecialchars($bodybuilder['height'], ENT_QUOTES, 'UTF-8'); ?>" required>
            </div>
            <div class="mb-3">
                <label for="weight" class="form-label">Weight</label>
                <input type="number" step="0.1" class="form-control" id="weight" name="weight" value="<?php echo htmlspecialchars($bodybuilder['weight'], ENT_QUOTES, 'UTF-8'); ?>" required>
            </div>
            <div class="mb-3">
                <label for="competitions" class="form-label">Competitions Won (comma separated)</label>
                <input type="text" class="form-control" id="competitions" name="competitions" value="<?php echo htmlspecialchars($bodybuilder['competitions_won'], ENT_QUOTES, 'UTF-8'); ?>" required>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Upload New Image</label>
                <input type="file" class="form-control" id="image" name="image">
                <small class="form-text text-muted">Leave empty to keep the current image.</small>
            </div>
            <div class="mb-3">
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <a href="detail.php?id=<?php echo htmlspecialchars($bodybuilder['id'], ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
    <?php include '../../theme/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
