<?php
include '../../lib/config.php';
if (isset($_GET['id'])) {
    $userId = $_GET['id'];
    $sql = "SELECT * FROM users WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) {
        echo "User not found!";
        exit;
    }
} else {
    echo "No user ID provided!";
    exit;
}
if (isset($_POST['delete'])) {
    header("Location: delete.php?id=" . $userId);
    exit();
}
if (isset($_POST['edit'])) {
    header("Location: edit.php?id=" . $userId);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../../theme/header.php'; ?>
    <div class="container mt-5">
        <h2>User Details</h2>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Username: <?php echo htmlspecialchars($user['username']); ?></h5>
                <p class="card-text">Email: <?php echo htmlspecialchars($user['id']); ?></p>
                <p class="card-text">Email: <?php echo htmlspecialchars($user['email']); ?></p>
                <p class="card-text">Role: <?php echo htmlspecialchars($user['role']); ?></p>
            </div>
        </div>
        <form method="POST" class="mt-3">
            <button type="submit" name="edit" class="btn btn-warning">Edit User</button>
            <button type="submit" name="delete" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?');">Delete User</button>
        </form>
        <a href="index.php" class="btn btn-primary mt-3">Back to User List</a>
    </div>
    <?php include '../../theme/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../theme/js/scripts.js"></script>
</body>
</html>
