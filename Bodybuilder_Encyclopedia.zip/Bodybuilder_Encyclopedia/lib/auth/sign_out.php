<?php
session_start();
session_unset();
session_destroy();
header("Location: ../../lib/auth/sign_in.php");
exit();
?>
