<?php
$host = 'localhost';
$db = 'workout_cms';
$user = 'root';
$pass = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log("Database connection error: " . $e->getMessage());
    echo "An error occurred while connecting to the database. Please try again later.";
    return [];
}
$query = "SELECT * FROM bodybuilders";
$stmt = $pdo->prepare($query);
$stmt->execute();
$bodybuilders = $stmt->fetchAll(PDO::FETCH_ASSOC);
return $bodybuilders;
?>
